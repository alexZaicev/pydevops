#!/bin/bash

CLASSPATH="./:./lib/*"
MAINCLASS="ch.bbp.fmm.pydevops.PydevopsUtils"

if [ -z $JAVA_HOME ]
then
	echo "JAVA_HOME environment variable is not set";
	exit 1;
fi

$JAVA_HOME/bin/java -cp $CLASSPATH $MAINCLASS "$@"
